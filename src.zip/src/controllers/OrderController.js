
const jwt = require("jsonwebtoken");
const { Pricing, Transaction, Order, ErrorLog, Negotiation, CropSpecification, Crop, CropRequest} = require("~database/models");
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
const Mailer = require('~services/mailer');
const md5  = require('md5');
const { reset } = require("nodemon");
const { use } = require("~routes/api");
const crypto = require('crypto');



class OrderController{

    static async hello(req , res){

        return res.status(200).json({
            message : "Hello Order"
        });
    }


    // createNewOrder
    /* ---------------------------- * CREATE NEW ORDER * ---------------------------- */
    static async createNewOrder(req , res){

        // return res.status(200).json({
            // message : "Create New Order"
            
        // });

        // return res.send(req.body);

        const errors = validationResult(req);

        try{
            
            // if(!errors.isEmpty()){
            //     return res.status(400).json({ 
            //          errors: errors.array() 
            //     });
            // }

            const randomid = crypto.randomBytes(16).toString('hex');


            
            // var obj = new Object();
            // obj = {
            //     "required_quantity": req.body.required_quantity,
            //     "offer_price": req.body.offer_price,
            //     "color": req.body.color,
            //     "moisture": req.body.moisture,
            //     "foreign_matter": req.body.foreign_matter,
            //     "broken_grains": req.body.broken_grains,
            //     "weevil": req.body.weevil,
            //     "dk": req.body.dk,
            //     "rotten_shriveled": req.body.rotten_shriveled,
            //     "test_weight": req.body.test_weight,
            //     "hectoliter": req.body.hectoliter,
            //     "hardness": req.body.hardness,
            //     "splits": req.body.splits,
            //     "oil_content": req.body.oil_content,
            //     "infestation":  req.body.infestation,
            //     "grain_size": req.body.grain_size,
            //     "total_defects": req.body.total_defects,
            //     "dockage": req.body.dockage, 
            //     "ash_content": req.body.ash_content, 
            //     "acid_ash": req.body.acid_ash,
            //     "volatile": req.body.volatile,
            //     "mold": req.body.mold, 
            //     "drying_process": req.body.drying_process,
            //     "dead_insect": req.body.dead_insect, 
            //     "mammalian": req.body.mammalian,
            //     "infested_by_weight": req.body.infested_by_weight,
            //     "curcumin_content": req.body.curcumin_content,
            //     "extraneous": req.body.extraneous,
            //     "kg": req.body.kg,
            //     "liters": req.body.liters
            // }

            // let stringifiedObj = JSON.stringify(obj);
            
            // return res.send(aa);

            // console.log(errors.isEmpty());

            let negotiation_id;
            negotiation_id = parseInt(req.body.negotiation_id);
            const accept_offer_type = req.body.accept_offer_type;
            const cropId = req.body.crop_id;

            /*************************************************************************************
             * IF NEGOTIATION ID IS SENT FROM PAYLOAD, IT MEANS THE OFFER WAS DIRECTLY ACCEPTED, *
             *               IF NOT THERE WAS A NEGOTIATION BEFORE ACCEPTING OFFER               *
             * *************************************************************************************/ 
            // accept_offer_type is direct or negotiation

            let theproduct;
            
            var findWantedCrops = await Crop.findOne({
                where: { type: "offer", id: req.body.crop_id }
            });

            if(!findWantedCrops){
                return res.status(200).json({
                    error: true,
                    message : "Sorry could not proceed, Crop with this specifications is not found.",
                    data: []
                });
            }else if(accept_offer_type == "" || accept_offer_type == null || accept_offer_type == undefined){
                return res.status(200).json({
                    error: true,
                    message : "Please indicate if you are accepting the offer directly or through a negotiation",
                    data: []
                });
            }else if(accept_offer_type == "direct"){
                // If accept_offer_type=="direct" get the crop details using its id
                var findCrop = await Crop.findOne({ 
                    include: [{
                        model: CropSpecification,
                        as: 'crop_specification',
                        order: [['id', 'DESC']],
                        limit: 1,
                    },
                    {
                        model: CropRequest,
                        as: 'crop_request',
                        order: [['id', 'DESC']],
                        limit: 1,
                        
                    }],
                    
                    where: { id: cropId, type: "offer" },
                    order: [['id', 'DESC']]
                });

                theproduct = findCrop;

            }else if(accept_offer_type == "negotiation"){

                const { count, rows } = await Negotiation.findAndCountAll({ 
                    where: { 
                        id: negotiation_id,
                        status: "accepted"
                    } 
                });
    
                if(count<1){
                    return res.status(200).json({
                        error : true,
                        message : `No accepted negotiation offer found`,
                        data : []
                    })
                }else{
                    var findCropNegotiationOffers = await Negotiation.findAndCountAll({ 
                        include: [{
                            model: CropSpecification,
                            as: 'crop_specification',
                            order: [['id', 'DESC']],
                            limit: 1,
                        }],
                        
                        
                        where: { 
                            messagetype: "offer",
                            status:     "accepted"
                        },
                        order: [['id', 'DESC']],
                        attributes: ['sender_id', 'receiver_id', 'crop_id', 'messagetype', 'status', 'created_at'],
                    });
        
                
                    /* --------------------- If fetched the accepted/declined Negotiation Transaction --------------------- */
                    
    
                    const findCrop = await Crop.findOne({ 
                        where: { 
                            id: findCropNegotiationOffers.rows[0].crop_id
                        } 
                    });
    
                    const findCropRequest = await CropRequest.findOne({ 
                        where: { 
                            crop_id: findCropNegotiationOffers.rows[0].crop_id
                        } 
                    });
    

                    var obj = new Object();
                    obj = {
                        "cropData": findCrop,
                        "cropSpecificationData": findCropRequest,
                        "negotiation": findCropNegotiationOffers
                    }

                    theproduct = obj;
                }

            }

            
            var createOrder = await Order.create({
                order_id: "ORD"+randomid,
                buyer_id: req.body.buyer_id,
                buyer_type: req.body.buyer_type,
                negotiation_id: req.body.negotiation_id,
                payment_option: req.body.payment_option,
                payment_status: req.body.payment_status,
                product: JSON.stringify(theproduct),
                // tracking_details: req.body.tracking_details,
                waybill_details: req.body.waybill_details,
                receipt_note: req.body.receipt_note,
                extra_documents: req.body.extra_documents
            })


            // // SEND INFORMATION TO PRODUCT SPECIFICATION TABLE //
            // if(sendnegotiation){
            //     var createCropSpecification = await CropSpecification.create({
            //         model_id: sendnegotiation.id,
            //         model_type: "offer",
            //         qty: req.body.required_quantity,
            //         price: req.body.price,
            //         color: req.body.color,
            //         moisture: req.body.moisture,
            //         foreign_matter: req.body.foreign_matter,
            //         broken_grains: req.body.broken_grains,
            //         weevil: req.body.weevil,
            //         dk: req.body.dk,
            //         rotten_shriveled: req.body.rotten_shriveled,
            //         test_weight: req.body.test_weight,
            //         hectoliter: req.body.hectoliter,
            //         hardness: req.body.hardness,
            //         splits: req.body.splits,
            //         oil_content: req.body.oil_content,
            //         infestation: req.body.infestation,
            //         grain_size: req.body.grain_size,
            //         total_defects: req.body.total_defects,
            //         dockage: req.body.dockage,
            //         ash_content: req.body.ash_content,
            //         acid_ash: req.body.acid_ash,
            //         volatile: req.body.volatile,
            //         mold: req.body.mold,
            //         drying_process: req.body.drying_process,
            //         dead_insect: req.body.dead_insect,
            //         mammalian: req.body.mammalian,
            //         infested_by_weight: req.body.infested_by_weight,
            //         curcumin_content: req.body.curcumin_content,
            //         extraneous: req.body.extraneous,
            //         kg: req.body.kg,
            //         liters: req.body.liters
            //     })
            // }
            // // SEND INFORMATION TO PRODUCT SPECIFICATION TABLE //

            
    
            return res.status(200).json({
                "error": false,
                "message": "New order created",
                "data": createOrder
            })
        }catch(e){
            // var logError = await ErrorLog.create({
            //     error_name: "Error on sending a new negotiation offer",
            //     error_description: e.toString(),
            //     route: "/api/crop/negotiation/sendoffer",
            //     error_code: "500"
            // });
            // if(logError){
                return res.status(500).json({
                    error: true,
                    message: 'Unable to complete request at the moment '+e.toString()
                })
            // }
        }

        
    }
    /* ---------------------------- * CREATE NEW ORDER * ---------------------------- */

}

module.exports = OrderController;