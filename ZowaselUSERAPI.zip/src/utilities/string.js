
module.exports = {
    capitalize : (string)=>{
        return string[0].toUpperCase() + string.substring(1);
    }
};