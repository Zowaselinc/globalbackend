const Server = require("./src/server");

Server.boot();